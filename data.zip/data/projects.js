projects ={
"type": "FeatureCollection",
"name": "projects",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:EPSG::4269" } },
"features": [
{ "type": "Feature", "properties": { "id": 1 }, "geometry": { "type": "Point", "coordinates": [ -127.39977779981956, 52.916036830228549 ] } },
{ "type": "Feature", "properties": { "id": 2 }, "geometry": { "type": "Point", "coordinates": [ -123.329202671770901, 55.924722794438438 ] } },
{ "type": "Feature", "properties": { "id": 3 }, "geometry": { "type": "Point", "coordinates": [ -138.195650965513835, 63.180965414003452 ] } },
{ "type": "Feature", "properties": { "id": 4 }, "geometry": { "type": "Point", "coordinates": [ -131.824315982481153, 64.242854577842223 ] } },
{ "type": "Feature", "properties": { "id": 5 }, "geometry": { "type": "Point", "coordinates": [ -128.284685436351879, 58.402464176728927 ] } },
{ "type": "Feature", "properties": { "id": 6 }, "geometry": { "type": "Point", "coordinates": [ -140.496410820497886, 68.13644817858443 ] } },
{ "type": "Feature", "properties": { "id": 7 }, "geometry": { "type": "Point", "coordinates": [ -91.649509283913872, 52.031129193696231 ] } },
{ "type": "Feature", "properties": { "id": 8 }, "geometry": { "type": "Point", "coordinates": [ -75.013245717106287, 50.61527697524452 ] } },
{ "type": "Feature", "properties": { "id": 9 }, "geometry": { "type": "Point", "coordinates": [ -117.134849216044671, 38.049588536485594 ] } },
{ "type": "Feature", "properties": { "id": 10 }, "geometry": { "type": "Point", "coordinates": [ -45.634312184233295, -4.956922598985102 ] } }
]
}
